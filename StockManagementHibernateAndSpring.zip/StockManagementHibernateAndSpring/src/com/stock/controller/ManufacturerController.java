package com.stock.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.stock.model.Manufacturers;
import com.stock.service.MService;




@Controller
public class ManufacturerController {
	
	@RequestMapping("/displayMForm")
	public ModelAndView displayMForm() {
		return new ModelAndView("AddManufacturer", "command", new Manufacturers());
	}
	
	@RequestMapping(value = "/addManufacturer", method = RequestMethod.POST)
	public ModelAndView addManufacturer(@ModelAttribute("manufacturers") Manufacturers manufacturers) {
		MService mService=new MService();
		mService.addManufacturer(manufacturers);
		return new ModelAndView("redirect:/displayMList");
	}
	
	@RequestMapping(value= "/displayMList")
	public ModelAndView displayMList(Model model) {
		MService mService=new MService();
		List<Manufacturers> mlist = mService.displayMList();
		model.addAttribute("mlist", mlist);
		return new ModelAndView("DisplayMList", "mList",mlist);
	}
	
	@RequestMapping(value="/displayEditForm/{mId}")
	public ModelAndView displayEditForm(@PathVariable("mId") int mId, Model model) {
		MService mService=new MService();
		Manufacturers manufacturers=mService.displayEditForm(mId);
		model.addAttribute("manufacturers",manufacturers);
		return new ModelAndView("EditMDetails","command",new Manufacturers());
	}
	
	@RequestMapping(value="/displayEditForm/updateMDetails/{mId}", method= RequestMethod.POST)
	public ModelAndView updateMDetails(@ModelAttribute("manufacturers") Manufacturers manufacturers,@PathVariable("mId") int mId) { 
		MService mService=new MService();
		mService.updateMDetails(manufacturers);
		return new ModelAndView("redirect:/displayMList");
	}
	
	@RequestMapping(value="/deleteM/{mId}")
	public ModelAndView deleteM(@PathVariable("mId") int mId, Model model) {
		MService mService=new MService();
		mService.deleteM(mId);
		return new ModelAndView("redirect:/displayMList");
	}
	
}
