package com.stock.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.stock.model.Manufacturers;
import com.stock.model.Products;
import com.stock.service.MService;

@Controller
public class ProductController {
@RequestMapping("/displayPForm")
public ModelAndView displayPForm() {
	return new ModelAndView("AddProduct", "command", new Products());
}
@RequestMapping(value = "/addProduct", method = RequestMethod.POST)
public ModelAndView addManufacturer(@ModelAttribute("products") Products products) {
	MService mService=new MService();
	mService.addProduct(products);
	return new ModelAndView("redirect:/displayPList");
}

@RequestMapping(value= "/displayPList")
public ModelAndView displayPList(Model model) {
	MService mService=new MService();
	List<Products> plist = mService.displayPList();
	model.addAttribute("plist", plist);
	return new ModelAndView("DisplayPList", "pList",plist);
}

@RequestMapping(value="/displayPEditForm/{pId}")
public ModelAndView displayPEditForm(@PathVariable("pId") int pId, Model model) {
	MService mService=new MService();
	Products products=mService.displayPEditForm(pId);
	model.addAttribute("products",products);
	return new ModelAndView("EditPDetails","command",new Products());
}

@RequestMapping(value="/displayPEditForm/updatePDetails/{pId}", method= RequestMethod.POST)
public ModelAndView updatePDetails(@ModelAttribute("products") Products products,@PathVariable("pId") int pId) { 
	MService mService=new MService();
	mService.updatePDetails(products);
	return new ModelAndView("redirect:/displayPList");
}

@RequestMapping(value="/deleteP/{pId}")
public ModelAndView deleteP(@PathVariable("pId") int pId, Model model) {
	MService mService=new MService();
	mService.deleteP(pId);
	return new ModelAndView("redirect:/displayPList");
}


@RequestMapping(value="/displayMP/{mId}")
public ModelAndView displayMP(@PathVariable("mId") int mId,HttpServletRequest request, HttpServletResponse response,Model model) {
	MService mService=new MService();
	List<Products> pList =mService.displayPList();
	System.out.println("hdcjshafkjkjfj");
	System.out.println(mId);
	model.addAttribute("mId",mId);
	return new ModelAndView("AddMP","pList",pList);
}

@RequestMapping(value="/displayMP/addMP/{mId}")
public ModelAndView addMP(@PathVariable("mId") int mId,HttpServletRequest request, HttpServletResponse response) {
	//int mId = Integer.parseInt(request.getParameter("mId"));
	System.out.println(mId);
	String pId[] = (request.getParameterValues("pId"));
	for(String s:pId){
		System.out.println(s);
	}

	MService mService=new MService();
	mService.addMP(mId, pId);
	return new ModelAndView("redirect:/displayMPList/{mId}");
}

@RequestMapping(value="/displayMPList/{mId}")
public ModelAndView displayMPList(Model model,@PathVariable("mId") int mId) {
	MService mService=new MService();
	List<Products> plist = mService.displayMPList(mId);
	model.addAttribute("plist", plist);
	return new ModelAndView("DisplayMPList", "pList",plist);
}
}
