package com.stock.dao;




import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.stock.model.Manufacturers;

public class Mdao {

	EntityManagerFactory emf = null;

	/* EntityManager */
	EntityManager em = null;

	Manufacturers manufacturers = new Manufacturers();

	EntityManager getEntityManager() {
		if (emf == null) {
			emf = Persistence.createEntityManagerFactory("persistence");
		}

		if (em == null) {
			em = emf.createEntityManager();
		}
		return em;
	}

	public void closeEntityManagerFactory() {
		if (emf != null) {
			emf.close();
		}
	}

	void closeEntityManager() {
		if (em != null) {
			em.close();
		}
	}
	
	public void addManufacturer(Manufacturers manufacturers) {
		try {
			em=getEntityManager();
			em.getTransaction().begin();
			em.persist(manufacturers);
			em.getTransaction().commit();
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		finally{
			closeEntityManager();
		}
		
		
	}

	public List<Manufacturers> displayMList() {
		List<Manufacturers> mList=new ArrayList<>(); 
		try {
			em=getEntityManager();
			em.getTransaction().begin();
			Query query=em.createQuery("from Manufacturers");
			mList=query.getResultList();
			em.getTransaction().commit();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		finally{
			closeEntityManager();
		}
		return mList;
	}
	public Manufacturers displayEditForm(int Id) {
		try {
			em=getEntityManager();
			em.getTransaction().begin();
			manufacturers=em.find(Manufacturers.class, Id);
			em.getTransaction().commit();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		finally{
			closeEntityManager();
		}
		return manufacturers;
	}

	public void updateMDetails(Manufacturers manufacturers) {
		Manufacturers m;
		try {
			System.out.println(manufacturers.getmEmail());
			em=getEntityManager();
			em.getTransaction().begin();
			m=em.find(Manufacturers.class, manufacturers.getmId());
			m.setmName(manufacturers.getmName());
			m.setmEmail(manufacturers.getmEmail());
			m.setmPhoneNo(manufacturers.getmPhoneNo());
			em.getTransaction().commit();			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		finally{
			closeEntityManager();
		}
	}

	public void deleteM(int mId) {
		
		try {
			em=getEntityManager();
			em.getTransaction().begin();
			em.remove(em.find(Manufacturers.class, mId));
			em.getTransaction().commit();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		finally{
			closeEntityManager();
		}
		
	}
}
