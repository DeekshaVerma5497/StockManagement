package com.stock.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.stock.model.Manufacturers;
import com.stock.model.Products;

public class Pdao {

	EntityManagerFactory emf = null;

	/* EntityManager */
	EntityManager em = null;

	Products products = new Products();

	EntityManager getEntityManager() {
		if (emf == null) {
			emf = Persistence.createEntityManagerFactory("persistence");
		}

		if (em == null) {
			em = emf.createEntityManager();
		}
		return em;
	}

	public void closeEntityManagerFactory() {
		if (emf != null) {
			emf.close();
		}
	}

	void closeEntityManager() {
		if (em != null) {
			em.close();
		}
	}

	public void addProduct(Products products) {

		try {
			em = getEntityManager();
			em.getTransaction().begin();
			em.persist(products);
			em.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}
	}

	public void updatePDetails(Products products) {
		Products p;
		
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			p = em.find(Products.class, products.getpId());
			p.setpName(products.getpName());
			p.setpQuantity(products.getpQuantity());
			p.setpPrice(products.getpPrice());
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}

	}

	public List<Products> displayPList() {
		List<Products> pList = new ArrayList<>();
		try {
			em = getEntityManager();
			em.getTransaction().begin();
			Query query = em.createQuery("from Products");
			pList = query.getResultList();
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}
		return pList;
	}

	public Products displayPEditForm(int Id) {
		try {
			em=getEntityManager();
			em.getTransaction().begin();
			products=em.find(Products.class, Id);
			em.getTransaction().commit();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
			closeEntityManager();
		}
		return products;
	}

	public void deleteP(int pId) {
		
		try {
			em=getEntityManager();
			em.getTransaction().begin();
			em.remove(em.find(Products.class, pId));
			em.getTransaction().commit();;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}

	}

	public List<Products> displayMPList(int mId) {
		
		List<Products> pList = new ArrayList<>();
		try {
			em=getEntityManager();
			em.getTransaction().begin();
			Query query=em.createQuery("from Products where manufacturers.mId="+mId);
			pList=query.getResultList();
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}
		return pList;

	}

	public void addMP(int mId, String[] pId) {
		try {
			Manufacturers ms;
			em = getEntityManager();
			em.getTransaction().begin();
			List<Products> pList=new ArrayList<>();
			ms=em.find(Manufacturers.class,mId);
			ms.setpList(pList);
			Products ps;
			for(String s:pId) 
			{
				int s1=Integer.parseInt(s);
				ps=em.find(Products.class, s1);
				pList.add(ps);
			}
			for(Products p:pList)
			{
				p.setManufacturers(ms);
			}
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}

	}

}
