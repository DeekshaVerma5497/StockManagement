package com.stock.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Products {
private
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pilot_generator")
@SequenceGenerator(name="pilot_generator", sequenceName="pilot_gen", initialValue=1, allocationSize=1)
int pId;
private
String pName;
int pQuantity;
double pPrice;

@ManyToOne
private Manufacturers manufacturers;

public Manufacturers getManufacturers() {
	return manufacturers;
}

public void setManufacturers(Manufacturers manufacturers) {
	this.manufacturers = manufacturers;
}

public Products() {
	// TODO Auto-generated constructor stub
}

public Products(int pId, String pName, int pQuantity, double pPrice) {
	super();
	this.pId = pId;
	this.pName = pName;
	this.pQuantity = pQuantity;
	this.pPrice = pPrice;
	
}

public int getpId() {
	return pId;
}

public void setpId(int pId) {
	this.pId = pId;
}

public String getpName() {
	return pName;
}

public void setpName(String pName) {
	this.pName = pName;
}

public int getpQuantity() {
	return pQuantity;
}

public void setpQuantity(int pQuantity) {
	this.pQuantity = pQuantity;
}

public double getpPrice() {
	return pPrice;
}

public void setpPrice(double pPrice) {
	this.pPrice = pPrice;
}




}
