package com.stock.service;

import java.util.List;

import com.stock.dao.Mdao;
import com.stock.dao.Pdao;
import com.stock.model.Manufacturers;
import com.stock.model.Products;

public class MService {

	public boolean addManufacturer(Manufacturers manufacturers) {
		Mdao mdao=new Mdao();
		return mdao.addManufacturer(manufacturers);
		
	}

	public List<Manufacturers> displayMList() {
		Mdao mdao=new Mdao();
		return mdao.displayMList();
	}

	public Manufacturers displayEditForm(int mId) {
		Mdao mdao=new Mdao();
		return mdao.displayEditForm(mId);
		
	}

	public void updateMDetails(Manufacturers manufacturers) {
		Mdao mdao=new Mdao();
		mdao.updateMDetails(manufacturers);
		
	}

	public void deleteM(int mId) {
		Mdao mdao=new Mdao();
		mdao.deleteM(mId);
		
	}

	public boolean addProduct(Products products) {
		Pdao pdao=new Pdao();
		return pdao.addProduct(products);
	}

	public void updatePDetails(Products products) {
		Pdao pdao=new Pdao();
		pdao.updatePDetails(products);
		
	}

	public List<Products> displayPList() {
		Pdao pdao=new Pdao();
		return pdao.displayPList();
	}

	public Products displayPEditForm(int pId) {
		Pdao pdao=new Pdao();
		return pdao.displayPEditForm(pId);
	}

	public void deleteP(int pId) {
		Pdao pdao=new Pdao();
		pdao.deleteP(pId);
	}

	public List<Products> displayMPList(int mId) {
		Pdao pdao=new Pdao();
		return pdao.displayMPList(mId);
		
	}

	public void addMP(int mId, String[] pId) {
		Pdao pdao=new Pdao();
		pdao.addMP(mId,pId);
		
	}

	

}
