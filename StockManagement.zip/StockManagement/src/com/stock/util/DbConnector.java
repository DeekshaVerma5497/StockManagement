package com.stock.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DbConnector {
public static Connection getConnecton() throws SQLException, ClassNotFoundException{
	ResourceBundle rb = ResourceBundle.getBundle("conn");
    String driver=rb.getString("db.driver");
	String url = rb.getString("db.url");
	String username = rb.getString("db.username");
	String password = rb.getString("db.password");
	Class.forName(driver);
	Connection conn=DriverManager.getConnection(url,username,password);
	return conn;

}
}
