package com.stock.model;

public class Products {
private
int pId;
String pName;
int pQuantity;
double pPrice;
int mId;

public Products() {
	// TODO Auto-generated constructor stub
}

public Products(int pId, String pName, int pQuantity, double pPrice, int mId) {
	super();
	this.pId = pId;
	this.pName = pName;
	this.pQuantity = pQuantity;
	this.pPrice = pPrice;
	this.mId = mId;
}

public int getpId() {
	return pId;
}

public void setpId(int pId) {
	this.pId = pId;
}

public String getpName() {
	return pName;
}

public void setpName(String pName) {
	this.pName = pName;
}

public int getpQuantity() {
	return pQuantity;
}

public void setpQuantity(int pQuantity) {
	this.pQuantity = pQuantity;
}

public double getpPrice() {
	return pPrice;
}

public void setpPrice(double pPrice) {
	this.pPrice = pPrice;
}

public int getmId() {
	return mId;
}

public void setmId(int mId) {
	this.mId = mId;
}


}
