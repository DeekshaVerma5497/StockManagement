package com.stock.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.stock.model.Manufacturers;
import com.stock.util.DbConnector;

public class Mdao {

	public boolean addManufacturer(Manufacturers manufacturers) {
		Connection con=null;
		boolean result=false;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement preparedStatement=con.prepareStatement("Insert into manufacturer(mName,mEmail,mPhoneNo) values(?,?,?)");
			preparedStatement.setString(1,manufacturers.getmName());
			preparedStatement.setString(2,manufacturers.getmEmail());
			preparedStatement.setString(3,manufacturers.getmPhoneNo());
			
			if(preparedStatement.executeUpdate()>0) {
				result=true;
			}
			
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
		
		
	}

	public List<Manufacturers> displayMList() {
		Connection con=null;
		List<Manufacturers> mList=new ArrayList<>();
		ResultSet rs;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("select * from manufacturer");
			rs=ps.executeQuery();
			while(rs.next()) {
				int mId=rs.getInt("mId");
				String mName=rs.getString("mName");
				String mEmail=rs.getString("mEmail");
				String mPhoneNo=rs.getString("mPhoneNo");
				System.out.println(mId);
				Manufacturers manufacturers=new Manufacturers();
				manufacturers.setmId(mId);
				manufacturers.setmName(mName);
				manufacturers.setmEmail(mEmail);
				manufacturers.setmPhoneNo(mPhoneNo);
				System.out.println(manufacturers.getmName());
				mList.add(manufacturers);	
			}
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return mList;
	}
	public Manufacturers displayEditForm(int Id) {
		Connection con=null;
		ResultSet rs;
		Manufacturers manufacturers=null;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("select * from manufacturer where mId=?");
			ps.setInt(1, Id);
			rs=ps.executeQuery();
			while(rs.next()) {
				int mId=rs.getInt("mId");
				String mName=rs.getString("mName");
				String mEmail=rs.getString("mEmail");
				String mPhoneNo=rs.getString("mPhoneNo");
				System.out.println(mId);
				manufacturers=new Manufacturers();
				manufacturers.setmId(mId);
				manufacturers.setmName(mName);
				manufacturers.setmEmail(mEmail);
				manufacturers.setmPhoneNo(mPhoneNo);
				System.out.println(manufacturers.getmName());
			}
			
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return manufacturers;
	}

	public void updateMDetails(Manufacturers manufacturers) {
		Connection con=null;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("update manufacturer set mName=?,mEmail=?,mPhoneNo=? where mId=? ");
			
			ps.setString(1, manufacturers.getmName());
			ps.setString(2, manufacturers.getmEmail());
			ps.setString(3, manufacturers.getmPhoneNo());
			ps.setInt(4,manufacturers.getmId());
			ps.executeUpdate();
			
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public void deleteM(int mId) {
		Connection con=null;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("delete from manufacturer where mId=?");
			ps.setInt(1, mId);
			ps.executeUpdate();
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		
		
	}
}
