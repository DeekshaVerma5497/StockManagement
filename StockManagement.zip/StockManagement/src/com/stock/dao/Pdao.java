package com.stock.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.stock.model.Manufacturers;
import com.stock.model.Products;
import com.stock.util.DbConnector;

public class Pdao {

	public boolean addProduct(Products products) {
		Connection con=null;
		boolean result=false;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement preparedStatement=con.prepareStatement("Insert into product(pName,pQuantity,pPrice) values(?,?,?)");
			preparedStatement.setString(1,products.getpName());
			preparedStatement.setInt(2,products.getpQuantity());
			preparedStatement.setDouble(3,products.getpPrice());
			
			if(preparedStatement.executeUpdate()>0) {
				result=true;
			}
			
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
	}

	public void updatePDetails(Products products) {
		Connection con=null;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("update product set pName=?,pQuantity=?,pPrice=?,mId=? where pId=? ");
			
			ps.setString(1, products.getpName());
			ps.setInt(2, products.getpQuantity());
			ps.setDouble(3, products.getpPrice());
			ps.setInt(4,products.getmId());
			ps.setInt(5, products.getpId());
			ps.executeUpdate();
			
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		
	}

	public List<Products> displayPList() {
		Connection con=null;
		List<Products> pList=new ArrayList<>();
		ResultSet rs;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("select * from product");
			rs=ps.executeQuery();
			while(rs.next()) {
				int pId=rs.getInt("pId");
				String pName=rs.getString("pName");
				int pQuantity=rs.getInt("pQuantity");
				double pPrice=rs.getDouble("pPrice");
				System.out.println(pId);
				Products products=new Products();
				products.setpId(pId);
				products.setpName(pName);
				products.setpQuantity(pQuantity);
				products.setpPrice(pPrice);
				System.out.println(products.getpName());
				pList.add(products);	
			}
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return pList;
	}

	public Products displayPEditForm(int Id) {
		Connection con=null;
		ResultSet rs;
		Products products=null;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("select * from product where pId=?");
			ps.setInt(1, Id);
			rs=ps.executeQuery();
			while(rs.next()) {
				int pId=rs.getInt("pId");
				String pName=rs.getString("pName");
				int pQuantity=rs.getInt("pQuantity");
				double pPrice=rs.getDouble("pPrice");
				int mId=rs.getInt("mId");
				System.out.println(pId);
				products=new Products();
				products.setpId(pId);
				products.setpName(pName);
				products.setpQuantity(pQuantity);
				products.setpPrice(pPrice);
				products.setmId(mId);
				System.out.println(products.getpName());
			}
			
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return products;
	}

	public void deleteP(int pId) {
		Connection con=null;
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("delete from product where pId=?");
			ps.setInt(1, pId);
			ps.executeUpdate();
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		
	}

	public List<Products> displayMPList(int mId) {
		Connection con=null;
		ResultSet rs;
		List<Products> pList=new ArrayList<>();
		try {
			con=DbConnector.getConnecton();
			PreparedStatement ps=con.prepareStatement("select * from product where mId=?");
			ps.setInt(1, mId);
			rs=ps.executeQuery();
			while(rs.next()) {
				int pId=rs.getInt("pId");
				String pName=rs.getString("pName");
				int pQuantity=rs.getInt("pQuantity");
				double pPrice=rs.getDouble("pPrice");
				System.out.println(pId);
				Products products=new Products();
				products.setpId(pId);
				products.setpName(pName);
				products.setpQuantity(pQuantity);
				products.setpPrice(pPrice);
				System.out.println(products.getpName());
				pList.add(products);	
			}
			
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return pList;
		
	}

	public void addMP(int mId, String[] Id) {
		
		System.out.println("addMP dao"+mId);
		Connection con=null;
		ResultSet rs;
		try {
			con=DbConnector.getConnecton();
			for(String s:Id){
				System.out.println(s);
				int pId=Integer.parseInt(s);
				PreparedStatement ps=con.prepareStatement("update product set mId=? where pId=?");
				ps.setInt(1,mId);
				ps.setInt(2, pId);
				ps.executeUpdate();
			}
	
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		finally {
			try {
				con.close();
			}
			catch(SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		
	}

}
