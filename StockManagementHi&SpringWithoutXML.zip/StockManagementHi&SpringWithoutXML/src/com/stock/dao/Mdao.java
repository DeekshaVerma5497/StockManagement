package com.stock.dao;

import java.util.List;

import com.stock.model.Manufacturers;

public interface Mdao {

	public void addManufacturer(Manufacturers manufacturers);
	
	public List<Manufacturers> displayMList();
	
	public Manufacturers displayEditForm(int Id);
	
	public void updateMDetails(Manufacturers manufacturers);
	
	public void deleteM(int mId);
	
}
