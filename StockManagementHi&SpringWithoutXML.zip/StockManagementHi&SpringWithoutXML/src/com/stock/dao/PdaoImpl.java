package com.stock.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.stock.model.Manufacturers;
import com.stock.model.Products;

@Repository("pdao")
public class PdaoImpl implements Pdao{

	@PersistenceContext
	private EntityManager em;

	public void addProduct(Products products) {
			em.persist(products);
	}

	public void updatePDetails(Products products) {
		Products p;
			p = em.find(Products.class, products.getpId());
			p.setpName(products.getpName());
			p.setpQuantity(products.getpQuantity());
			p.setpPrice(products.getpPrice());
	}

	public List<Products> displayPList() {
		List<Products> pList = new ArrayList<>();
			Query query = em.createQuery("from Products");
			pList = query.getResultList();
		return pList;
	}

	public Products displayPEditForm(int Id) {
		Products products;
			products=em.find(Products.class, Id);
		return products;
	}

	public void deleteP(int pId) {
			em.remove(em.find(Products.class, pId));
	}

	public List<Products> displayMPList(int mId) {
		
		List<Products> pList = new ArrayList<>();
			Query query=em.createQuery("from Products where manufacturers.mId="+mId);
			pList=query.getResultList();
		return pList;

	}

	public void addMP(int mId, String[] pId) {
			Manufacturers ms;
			List<Products> pList=new ArrayList<>();
			ms=em.find(Manufacturers.class,mId);
			ms.setpList(pList);
			Products ps;
			for(String s:pId) 
			{
				int s1=Integer.parseInt(s);
				ps=em.find(Products.class, s1);
				pList.add(ps);
			}
			for(Products p:pList)
			{
				p.setManufacturers(ms);
			}

	}

}
