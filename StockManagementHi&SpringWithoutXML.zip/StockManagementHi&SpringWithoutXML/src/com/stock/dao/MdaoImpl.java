package com.stock.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.stock.model.Manufacturers;

@Repository("mdao")
public class MdaoImpl implements Mdao {

	@PersistenceContext
	private EntityManager em;

	public void addManufacturer(Manufacturers manufacturers) {

		em.persist(manufacturers);

	}

	public List<Manufacturers> displayMList() {
		List<Manufacturers> mList = new ArrayList<>();
		Query query = em.createQuery("from Manufacturers");
		mList = query.getResultList();
		return mList;
	}

	public Manufacturers displayEditForm(int Id) {
		Manufacturers manufacturers;
		manufacturers = em.find(Manufacturers.class, Id);
		return manufacturers;
	}

	public void updateMDetails(Manufacturers manufacturers) {
		Manufacturers m;
		System.out.println(manufacturers.getmEmail());
		m = em.find(Manufacturers.class, manufacturers.getmId());
		m.setmName(manufacturers.getmName());
		m.setmEmail(manufacturers.getmEmail());
		m.setmPhoneNo(manufacturers.getmPhoneNo());
	}

	public void deleteM(int mId) {
		em.remove(em.find(Manufacturers.class, mId));
	}
}
