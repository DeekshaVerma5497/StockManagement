package com.stock.dao;

import java.util.List;

import com.stock.model.Products;

public interface Pdao {	
	
	public void addProduct(Products products);
	
	public void updatePDetails(Products products);
	
	public List<Products> displayPList();
	
	public Products displayPEditForm(int Id);
	
	public void deleteP(int pId);
	
	public List<Products> displayMPList(int mId);
	
	public void addMP(int mId, String[] pId);
	
	
	
}
