package com.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.stock.dao.Mdao;
import com.stock.dao.MdaoImpl;
import com.stock.dao.Pdao;
import com.stock.dao.PdaoImpl;
import com.stock.model.Manufacturers;
import com.stock.model.Products;

@Service
@Qualifier("mService")
public class MServiceImpl implements MService{
	
	@Autowired(required = true)
	private Mdao mdao;
	
	@Autowired(required=true)
	private Pdao pdao;

	@Transactional
	public void addManufacturer(Manufacturers manufacturers) {
		mdao.addManufacturer(manufacturers);
		
	}

	@Transactional
	public List<Manufacturers> displayMList() {
		return mdao.displayMList();
	}

	@Transactional
	public Manufacturers displayEditForm(int mId) {
		return mdao.displayEditForm(mId);
		
	}

	@Transactional
	public void updateMDetails(Manufacturers manufacturers) {
		mdao.updateMDetails(manufacturers);
		
	}

	@Transactional
	public void deleteM(int mId) {
		mdao.deleteM(mId);
		
	}

	@Transactional
	public void updatePDetails(Products products) {
		pdao.updatePDetails(products);
		
	}

	@Transactional
	public List<Products> displayPList() {
		return pdao.displayPList();
	}

	@Transactional
	public Products displayPEditForm(int pId) {
		return pdao.displayPEditForm(pId);
	}

	@Transactional
	public void deleteP(int pId) {
		pdao.deleteP(pId);
	}

	@Transactional
	public List<Products> displayMPList(int mId) {
		return pdao.displayMPList(mId);
		
	}

	@Transactional
	public void addMP(int mId, String[] pId) {
		pdao.addMP(mId,pId);
		
	}

	@Transactional
	public void addProduct(Products products) {
		pdao.addProduct(products);
		
	}

	

}
