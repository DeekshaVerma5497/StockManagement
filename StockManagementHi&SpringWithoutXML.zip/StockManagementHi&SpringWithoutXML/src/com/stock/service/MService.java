package com.stock.service;

import java.util.List;

import com.stock.model.Manufacturers;
import com.stock.model.Products;

public interface MService {

	public void addManufacturer(Manufacturers manufacturers);
	
	public List<Manufacturers> displayMList();
	
	public Manufacturers displayEditForm(int mId);
	
	public void updateMDetails(Manufacturers manufacturers);
	
	public void deleteM(int mId);
	
	public void updatePDetails(Products products);
	
	public List<Products> displayPList();
	
	public Products displayPEditForm(int pId);
	
	public void deleteP(int pId);
	
	public List<Products> displayMPList(int mId);
	
	public void addMP(int mId, String[] pId);
	
	public void addProduct(Products products);
	
	
	
}
