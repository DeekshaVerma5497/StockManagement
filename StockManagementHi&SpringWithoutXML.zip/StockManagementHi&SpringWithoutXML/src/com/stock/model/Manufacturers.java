package com.stock.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Manufacturers {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
//SEQUENCE, generator = "manufacturer_generators")
//@SequenceGenerator(name ="manufacturer_generators", sequenceName= "manufacturer_seq", initialValue = 1, allocationSize = 1)
private int mId;
private
String mName;
String mEmail;
String mPhoneNo;

@OneToMany(mappedBy = "manufacturers", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
private List<Products> pList=new ArrayList<>();



public List<Products> getpList() {
	return pList;
}

public void setpList(List<Products> pList) {
	this.pList = pList;
}

public Manufacturers() {
	// TODO Auto-generated constructor stub
}

public Manufacturers(int mId, String mName, String mEmail, String mPhoneNo) {
	super();
	this.mId = mId;
	this.mName = mName;
	this.mEmail = mEmail;
	this.mPhoneNo = mPhoneNo;
}

public int getmId() {
	return mId;
}

public void setmId(int mId) {
	this.mId = mId;
}

public String getmName() {
	return mName;
}

public void setmName(String mName) {
	this.mName = mName;
}

public String getmEmail() {
	return mEmail;
}

public void setmEmail(String mEmail) {
	this.mEmail = mEmail;
}

public String getmPhoneNo() {
	return mPhoneNo;
}

public void setmPhoneNo(String mPhoneNo) {
	this.mPhoneNo = mPhoneNo;
}


}
